package com.example.examplemod;

import com.emr09.nekoLoader.api.ModInitializer;

public class ExampleMod implements ModInitializer {
    @Override
    public void onInitialize() {
        System.out.println("[ExampleMod] Hello from a Neko mod!");
    }
}
