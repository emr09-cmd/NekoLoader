# Example Neko Mod (Gradle)

## Build on Windows (PowerShell)

```powershell
cd example-nekomod
.\gradlew.bat build
```

Output jar:

```
build\libs\examplemod-1.0.0.jar
```

Copy it into:

```
%APPDATA%\.minecraft\mods\
```

## Requirements

- **Java 25** (same as Minecraft 26.2)
- Internet on first run (downloads Gradle 8.12.1)

## neko.mod.json

Jars **without** `neko.mod.json` are **Unknown** and **not loaded**.

## Entrypoint

```java
public class ExampleMod implements ModInitializer {
    @Override
    public void onInitialize() {
        System.out.println("Hello Neko mod");
    }
}
```
