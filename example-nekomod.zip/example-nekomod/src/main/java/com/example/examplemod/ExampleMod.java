package com.example.examplemod;

import com.emr09.nekoLoader.api.ModInitializer;
import com.emr09.nekoLoader.api.NekoLoader;
import com.emr09.nekoLoader.api.event.PlayerJoinEvent;

public class ExampleMod implements ModInitializer {

    @Override
    public void onInitialize() {
        NekoLoader.getLogger().info("ExampleMod initializing...");

        PlayerJoinEvent.register(event -> {
            event.getPlayer().sendChatMessage("§aExample Mod loaded successfully!");
            NekoLoader.getLogger().info("Player joined: " + event.getPlayer().getName());
        });
    }
}
